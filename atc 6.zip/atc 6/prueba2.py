# import pandas as pd
# import numpy as np
# from sklearn.linear_model import LinearRegression

# # Cargar el dataset
# df = pd.read_csv('Datos_Limpios_pais.csv')

# # Preprocesamiento de datos
# df['host_acceptance_rate'] = df['host_acceptance_rate'].astype(str).str.replace('%', '').astype(float)
# df['price'] = df['price'].astype(str).str.replace('$', '').str.replace(',', '').astype(float)

# # Verificar si las columnas necesarias existen
# required_columns = ['host_acceptance_rate', 'review_scores_cleanliness', 'minimum_nights', 'price']
# missing_columns = [col for col in required_columns if col not in df.columns]

# if missing_columns:
#     print(f"Faltan las siguientes columnas en el dataset: {missing_columns}")
# else:
#     # Regresión lineal simple
#     X_simple = df[['host_acceptance_rate']]
#     y = df['price']
#     model_simple = LinearRegression()
#     model_simple.fit(X_simple, y)
#     r2_simple = model_simple.score(X_simple, y)
    
#     # Regresión lineal múltiple
#     X_multiple = df[['host_acceptance_rate', 'review_scores_cleanliness', 'minimum_nights']]
#     model_multiple = LinearRegression()
#     model_multiple.fit(X_multiple, y)
#     r2_multiple = model_multiple.score(X_multiple, y)
    
#     # Comparación de resultados
#     print(f"R^2 de regresión lineal simple: {r2_simple:.4f}")
#     print(f"R^2 de regresión lineal múltiple: {r2_multiple:.4f}")
    
#     if r2_multiple > r2_simple:
#         print("La regresión múltiple tiene un mejor ajuste que la simple.")
#     else:
#         print("La regresión múltiple NO mejora el ajuste respecto a la simple.")

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import statsmodels.api as sm

# Cargar el dataset
df = pd.read_csv('Datos_Limpios_pais.csv')

# Lista de variables predictoras
predictors = ['id', 'host_acceptance_rate', 'host_is_superhost', 'host_total_listings_count', 
              'room_type', 'accommodates', 'bedrooms', 'price', 'review_scores_value', 'reviews_per_month']

# Inicializar un diccionario para almacenar los coeficientes de los modelos
model_coefficients = {}

# Función para crear y ajustar un modelo de regresión lineal múltiple
def create_and_evaluate_model(target_variable):
    # Seleccionar la variable dependiente
    y = df[target_variable]
    
    # Seleccionar las variables predictoras
    X = df[predictors]

    # Dividir el dataset en conjuntos de entrenamiento y prueba
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Crear una instancia del modelo de regresión lineal
    model = LinearRegression()

    # Ajustar el modelo a los datos de entrenamiento
    model.fit(X_train, y_train)

    # Predecir los valores en el conjunto de prueba
    y_pred = model.predict(X_test)

    # Calcular métricas de evaluación
    r2 = r2_score(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))

    # Almacenar los coeficientes del modelo
    model_coefficients[target_variable] = model.coef_

    print(f'Modelo para {target_variable}')
    print('R²:', r2)
    print('RMSE:', rmse)
    print('Coeficientes:', model.coef_)
    print()

# Crear y evaluar modelos para cada variable cuantitativa
for target_variable in predictors:
    create_and_evaluate_model(target_variable)

# Calcular la matriz de correlación para comparar con los coeficientes
corr_matrix = df.corr()

# Comparar los coeficientes obtenidos con los coeficientes de la matriz de correlación
print('Coeficientes obtenidos en los modelos:')
print(pd.DataFrame(model_coefficients, index=predictors))

print('Coeficientes de correlación:')
print(corr_matrix.loc[predictors, predictors])
